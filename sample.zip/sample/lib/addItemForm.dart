import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';


class addItemForm extends StatefulWidget {


  @override
  _addItemFormState createState() {
   return new _addItemFormState();
  }
}
class _addItemFormState extends State<addItemForm>{
GlobalKey<FormState> _key = GlobalKey();
bool _validate = false;
String name, category;
double quantity;
File _image;

Future getimage() async{
  var image = await ImagePicker.pickImage(source: ImageSource.gallery);
   setState(() {
     _image = image;
   });
}

@override
Widget build(BuildContext context) {
  return new SingleChildScrollView(
    child: new Container(
      margin: new EdgeInsets.all(15.0),
      child: new Form(
        key: _key,
        autovalidate: _validate,
        child: itemform(),
      ),
    ),
  );
}
Widget itemform()
{
  return Container(
    width: 300,
    child: new Column(
      children: <Widget>[


        
        new TextFormField(
            decoration: new InputDecoration(hintText: 'Enter the name'),
            validator: validateName,
            onSaved: (String val) {
              name  = val;
            }
        ),

        new TextFormField(
            decoration: new InputDecoration(hintText: 'Enter the Category'),
            validator: validateCategory,
            onSaved: (String val) {
              category = val;
            }
        ),
        new TextFormField(
            decoration: new InputDecoration(hintText: 'Enter the quantity'),
            
            keyboardType: TextInputType.number,
            onSaved: (String val) {
              quantity = double.parse(val);
            }
        ),
        new SizedBox(height: 15.0),
        new RaisedButton(
            onPressed:getimage,
            child: new Text('Capture'),
        ),

        new SizedBox(height: 15.0),
        new RaisedButton(onPressed: _sendToServer, child: new Text('Upload'),
        )
      ],
    ),
  );
}
String validateName(String value) {
  String patttern = r'(^[a-zA-Z ]*$)';
  RegExp regExp = new RegExp(patttern);
  if (value.length == 0) {
    return "Title is Required";
  } else if (!regExp.hasMatch(value)) {
    return "Title must be a-z and A-Z";
  }
  return null;
}

String validateCategory(String value) {
  String patttern = r'(^[a-zA-Z ]*$)';
  RegExp regExp = new RegExp(patttern);
  if (value.length == 0) {
    return "Author is Required";
  } else if (!regExp.hasMatch(value)) {
    return "Author must be a-z and A-Z";
  }
  return null;
}


_sendToServer(){
  Firestore.instance.collection('inventory').add({"name": "$name", "category": "$category", "quantity": "$quantity"}).catchError((e){print(e);});
  final StorageReference firebaseStorageRef =
  FirebaseStorage.instance.ref().child('');
  final StorageUploadTask task =
  firebaseStorageRef.putFile(_image);
}
}


