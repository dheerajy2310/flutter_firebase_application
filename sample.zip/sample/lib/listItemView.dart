import 'package:flutter/cupertino.dart';

class listItemView extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}